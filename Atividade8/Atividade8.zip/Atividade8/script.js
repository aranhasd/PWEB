// Dados simulados (idade, sexo, opinião)
const respostas = [
    { idade: 25, sexo: 'F', opiniao: 4 },
    { idade: 34, sexo: 'M', opiniao: 3 },
    { idade: 20, sexo: 'F', opiniao: 2 },
    { idade: 45, sexo: 'M', opiniao: 1 },
    { idade: 30, sexo: 'F', opiniao: 4 },
    { idade: 50, sexo: 'M', opiniao: 3 },
    { idade: 19, sexo: 'M', opiniao: 2 },
    { idade: 38, sexo: 'F', opiniao: 1 },
    { idade: 27, sexo: 'M', opiniao: 3 },
    { idade: 23, sexo: 'F', opiniao: 4 },
    { idade: 60, sexo: 'F', opiniao: 3 },
    { idade: 32, sexo: 'M', opiniao: 2 },
    // Adicione mais dados para totalizar 45 respostas
];

// Função para calcular a média da idade
function calcularMediaIdade(respostas) {
    let somaIdade = 0;
    respostas.forEach(resposta => {
        somaIdade += resposta.idade;
    });
    return somaIdade / respostas.length;
}

// Função para encontrar a pessoa mais velha
function encontrarPessoaMaisVelha(respostas) {
    let maisVelha = respostas[0].idade;
    respostas.forEach(resposta => {
        if (resposta.idade > maisVelha) {
            maisVelha = resposta.idade;
        }
    });
    return maisVelha;
}

// Função para encontrar a pessoa mais nova
function encontrarPessoaMaisNova(respostas) {
    let maisNova = respostas[0].idade;
    respostas.forEach(resposta => {
        if (resposta.idade < maisNova) {
            maisNova = resposta.idade;
        }
    });
    return maisNova;
}

// Função para contar pessoas que responderam péssimo
function contarPessimo(respostas) {
    let pessimo = 0;
    respostas.forEach(resposta => {
        if (resposta.opiniao === 1) {
            pessimo++;
        }
    });
    return pessimo;
}

// Função para calcular porcentagem de ótimo e bom
function calcularPorcentagemOtimoBom(respostas) {
    let otimoBom = 0;
    respostas.forEach(resposta => {
        if (resposta.opiniao === 3 || resposta.opiniao === 4) {
            otimoBom++;
        }
    });
    return (otimoBom / respostas.length) * 100;
}

// Função para contar número de homens e mulheres
function contarHomensMulheres(respostas) {
    let homens = 0;
    let mulheres = 0;
    respostas.forEach(resposta => {
        if (resposta.sexo === 'M') {
            homens++;
        } else if (resposta.sexo === 'F') {
            mulheres++;
        }
    });
    return { homens, mulheres };
}

// Chamando as funções
const mediaIdade = calcularMediaIdade(respostas);
const maisVelha = encontrarPessoaMaisVelha(respostas);
const maisNova = encontrarPessoaMaisNova(respostas);
const pessimo = contarPessimo(respostas);
const porcentagemOtimoBom = calcularPorcentagemOtimoBom(respostas);
const { homens, mulheres } = contarHomensMulheres(respostas);

// Exibindo resultados
console.log(`Média de idade: ${mediaIdade.toFixed(2)}`);
console.log(`Idade da pessoa mais velha: ${maisVelha}`);
console.log(`Idade da pessoa mais nova: ${maisNova}`);
console.log(`Quantidade de pessoas que responderam péssimo: ${pessimo}`);
console.log(`Porcentagem de pessoas que responderam ótimo ou bom: ${porcentagemOtimoBom.toFixed(2)}%`);
console.log(`Número de homens: ${homens}`);
console.log(`Número de mulheres: ${mulheres}`);



document.getElementById("titulo").textContent = "Escolha a página.";
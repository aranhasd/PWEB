function calcMedia(){
    let nomeAluno = (document.getElementById("nomeAluno").value);
    let num1 = parseFloat(document.getElementById("nota1Aluno").value);
    let num2 = parseFloat(document.getElementById("nota2Aluno").value);
    let num3 = parseFloat(document.getElementById("nota3Aluno").value);
    let num4 = parseFloat(document.getElementById("nota4Aluno").value);

    if(!isNaN(num1) && !isNaN(num2) && !isNaN(num3)){
        let media = (num1 + num2 + num3 + num4)/4;
        document.getElementById("mediaAluno").innerText = "Média do aluno " + nomeAluno + " é: " + media;
    } else {
        window.alert("Número(s) inválido(s).");
    }
}

function apagarTudo(){
    document.getElementById("nomeAluno").value = "";
    document.getElementById("nota1Aluno").value = "";
    document.getElementById("nota2Aluno").value = "";
    document.getElementById("nota3Aluno").value = "";
    document.getElementById("nota4Aluno").value = "";
    document.getElementById("mediaAluno").innerText = "Média final: ";
}
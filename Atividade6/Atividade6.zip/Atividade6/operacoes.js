function calcular(){
    let num1 = parseFloat(document.getElementById("primeiroNumero").value);
    let num2 = parseFloat(document.getElementById("segundoNumero").value);

    if(!isNaN(num1) && !isNaN(num2)){
        let soma = (num1 + num2);
        document.getElementById("somaNumeros").innerText="Soma dos números: "+ soma;
        let subtracao = (num1 - num2);
        document.getElementById("subtracaoNumeros").innerText="Subtração do primeiro pelo segundo: "+ subtracao;
        let produto = (num1 * num2);
        document.getElementById("produtoNumeros").innerText="Produto dos números: "+ produto;
        let divisao = (num1 / num2);
        document.getElementById("divisaoNumeros").innerText="Divisão do primeiro pelo segundo: "+ divisao.toFixed(2);
        let resto = (num1 % num2);
        document.getElementById("restoNumeros").innerText="Resto da divisão do primeiro pelo segundo: "+ resto;
    }

    else {
        window.alert("Número(s) inválido(s).");
    }
}

function apagarTudo(){
    document.getElementById("primeiroNumero").value = "";
    document.getElementById("segundoNumero").value = "";
    document.getElementById("somaNumeros").innerText="Soma dos números: ";
    document.getElementById("subtracaoNumeros").innerText="Subtração do primeiro pelo segundo: ";
    document.getElementById("produtoNumeros").innerText="Produto dos números: ";
    document.getElementById("divisaoNumeros").innerText="Divisão do primeiro pelo segundo: ";
    document.getElementById("restoNumeros").innerText="Resto da divisão do primeiro pelo segundo: ";
}
document.getElementById('palindromoForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const texto = document.getElementById('texto').value;
    const textoMaiusculo = texto.toUpperCase();
    const textoInvertido = textoMaiusculo.split('').reverse().join('');

    const resultado = textoMaiusculo === textoInvertido ? "É um palíndromo" : "Não é um palíndromo";

    document.getElementById('resultado').textContent = resultado;
});

document.getElementById('ordenarNumerosForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const num1 = parseFloat(document.getElementById('num1').value);
    const num2 = parseFloat(document.getElementById('num2').value);
    const num3 = parseFloat(document.getElementById('num3').value);

    const numerosOrdenados = [num1, num2, num3].sort((a, b) => a - b);

    document.getElementById('resultado').textContent = `Números em ordem crescente: ${numerosOrdenados.join(', ')}`;
});

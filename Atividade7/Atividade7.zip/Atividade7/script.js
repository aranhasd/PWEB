function getEscolhaMaquina() {
    const randomNum = Math.random();
    if (randomNum < 0.33) {
        return "pedra";
    } else if (randomNum < 0.66) {
        return "papel";
    } else {
        return "tesoura";
    }
}

function escolheGanhador(escolhaJogador, escolhaMaquina) {
    if (escolhaJogador === escolhaMaquina) {
        return "Empate!";
    }
    if (escolhaJogador === "pedra") {
        return (escolhaMaquina === "tesoura") ? "Você ganhou! Pedra quebra tesoura." : "Você perdeu! Papel cobre pedra.";
    } else if (escolhaJogador === "papel") {
        return (escolhaMaquina === "pedra") ? "Você ganhou! Papel cobre pedra." : "Você perdeu! Tesoura corta papel.";
    } else if (escolhaJogador === "tesoura") {
        return (escolhaMaquina === "papel") ? "Você ganhou! Tesoura corta papel." : "Você perdeu! Pedra quebra tesoura.";
    }
}

function playGame(escolhaJogador) {
    const escolhaMaquina = getEscolhaMaquina();
    const resultado = escolheGanhador(escolhaJogador, escolhaMaquina);
    alert(`Você escolheu: ${escolhaJogador} \nComputador escolheu: ${escolhaMaquina} \n${resultado}`);
}

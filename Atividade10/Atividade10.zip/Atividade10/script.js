function calcularIMC() {
    let altura = parseFloat(document.getElementById('altura').value);
    let peso = parseFloat(document.getElementById('peso').value);

    if (!altura || !peso) {
        document.getElementById('resultado').innerHTML = "<span class='alert'>Por favor, insira valores válidos para altura e peso.</span>";
        return;
    }
    
    let imc = peso / (altura * altura);
    let classificacao = classificarIMC(imc);

    document.getElementById('resultado').innerHTML = `Seu IMC é: ${imc.toFixed(2)} (${classificacao})`;
}

function classificarIMC(imc) {
    if (imc < 18.5) {
        return "Magreza";
    } else if (imc >= 18.5 && imc <= 24.9) {
        return "Normal";
    } else if (imc >= 25 && imc <= 29.9) {
        return "Sobrepeso";
    } else if (imc >= 30 && imc <= 39.9) {
        return "Obesidade";
    } else {
        return "Obesidade Grave";
    }
}

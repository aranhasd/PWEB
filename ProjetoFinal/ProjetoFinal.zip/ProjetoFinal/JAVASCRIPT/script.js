document.addEventListener("DOMContentLoaded", loadTasks);

function showForm() {
    document.getElementById("taskForm").style.display = "flex";
}

function hideForm() {
    document.getElementById("taskForm").style.display = "none";
}

function addTask() {
    const task = {
        id: Date.now(),
        name: document.getElementById("taskName").value,
        description: document.getElementById("taskDescription").value,
        date: document.getElementById("taskDate").value,
        responsible: document.getElementById("taskResponsible").value,
        priority: document.getElementById("taskPriority").value,
        status: document.getElementById("taskStatus").value
    };

    saveTask(task);
    hideForm();
    loadTasks();
}

function saveTask(task) {
    const tasks = getTasks();
    tasks.push(task);
    localStorage.setItem("tasks", JSON.stringify(tasks));
}

function getTasks() {
    return JSON.parse(localStorage.getItem("tasks")) || [];
}

function loadTasks() {
    const columns = { "todo": "todo", "in-progress": "in-progress", "done": "done" };
    for (let column in columns) {
        document.getElementById(columns[column]).querySelector(".task-list").innerHTML = "";
    }

    const tasks = getTasks();
    tasks.forEach(task => {
        const taskElement = document.createElement("div");
        taskElement.className = `task ${task.status}`;
        taskElement.draggable = true;
        taskElement.innerHTML = `
            <strong>${task.name}</strong><br>
            ${task.description}<br>
            Data: ${task.date}<br>
            Prioridade: ${task.priority}<br>
            Responsável: ${task.responsible}
            <button class="delete-btn" onclick="deleteTask(${task.id})">Excluir</button>
        `;

        taskElement.ondragstart = (e) => {
            e.dataTransfer.setData("text", task.id);
        };

        document.getElementById(task.status).querySelector(".task-list").appendChild(taskElement);
    });
}

function deleteTask(taskId) {
    let tasks = getTasks();
    tasks = tasks.filter(task => task.id !== taskId);
    localStorage.setItem("tasks", JSON.stringify(tasks));
    loadTasks();
}

document.querySelectorAll(".column").forEach(column => {
    column.ondragover = (e) => e.preventDefault();

    column.ondrop = (e) => {
        const taskId = e.dataTransfer.getData("text");
        const tasks = getTasks();
        const task = tasks.find(t => t.id == taskId);

        if (task) {
            task.status = column.id;
            localStorage.setItem("tasks", JSON.stringify(tasks));
            loadTasks();
        }
    };
});
